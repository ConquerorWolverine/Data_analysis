datasketch
==========

Probabilistic data structures implemented in Python.
